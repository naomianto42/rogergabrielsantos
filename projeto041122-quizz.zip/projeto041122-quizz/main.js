var numeros = 0;

function trocaImg(){

if (numeros <=5){
    numeros++;
}else{
    numeros = 1;
}


var url = "url('img/"+numeros+".jfif')";

document.getElementById('carro').style.backgroundImage = url;

}

trocaImg(1);

function destrocaImg(){

    if (numeros <=6 && numeros >=2){
        numeros--;
    }else{
        numeros = 6;
    }
    
    
    var url = "url('img/"+numeros+".jfif')";
    
    document.getElementById('carro').style.backgroundImage = url;
    
    }
    